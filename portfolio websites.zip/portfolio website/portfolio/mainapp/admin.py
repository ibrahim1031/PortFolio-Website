from django.contrib import admin
from .models import SubscribingForm,FeedbackForm

# Register your models here.

admin.site.register(SubscribingForm)
admin.site.register(FeedbackForm)