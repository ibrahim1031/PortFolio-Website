from django.urls import path
from . import views
urlpatterns = [
    path('',views.hello,name='home'),
     path('feedback/', views.feedbackview, name='feedbackview'),
    path('subscription/',views.Subscriptionview,name='subscriptionview'),
    path('perform_action/', views.perform_action, name='perform_action'),
    path('index/',views.index)
]