from django import forms
from .models import FeedbackForm,SubscribingForm

class MyFeedbackForm(forms.ModelForm):
    class Meta:
        model = FeedbackForm
        fields = "__all__"

class MySubscriptionForm(forms.ModelForm):
    class Meta:
        model = SubscribingForm
        fields = "__all__"        