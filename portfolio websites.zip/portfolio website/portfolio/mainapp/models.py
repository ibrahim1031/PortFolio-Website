from django.db import models

# Create your models here.

class FeedbackForm(models.Model):
    name = models.CharField(max_length=100)
    subject = models.CharField(max_length=100)
    feedback = models.TextField(max_length=1000) 

class SubscribingForm(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField()
    PhoneNumber= models.IntegerField()    
    password = models.IntegerField() 