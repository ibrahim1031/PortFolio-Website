from django.shortcuts import render
from django.http import HttpResponse
from .forms import MyFeedbackForm,MySubscriptionForm

# Create your views here.
def hello(request):
    return render(request,'home.html')


def feedbackview(request):
    form = MyFeedbackForm()
    if request.method == 'POST':
        form  = MyFeedbackForm(request.POST)
        if form.is_valid():
            form.save()
    context = {'form':form}
    return render(request,'form.html',context)  

def Subscriptionview(request):
    form = MySubscriptionForm()
    if request.method == 'POST':
        form  = MySubscriptionForm(request.POST)
        if form.is_valid():
            form.save()
    context = {'form':form}
    return render(request,'form.html',context)  

def index(request):
    return render(request, 'index.html')

def perform_action(request):
    # Do something here, like processing the action
    return HttpResponse("Action performed!")
